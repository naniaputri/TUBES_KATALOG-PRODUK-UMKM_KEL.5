


<?php $__env->startSection('title', 'Daftar Produk'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
    <div>
        <div class="text-muted small mb-1">Produk / Daftar Produk</div>
        <h1 class="h3 fw-bold mb-1">Daftar Produk</h1>
        <p class="text-muted mb-0">
            Kelola produk UMKM, lihat detail, ubah, dan hapus data.
        </p>
    </div>

    <a href="<?php echo e(route('produk.create')); ?>" class="btn btn-hijau px-3 py-2">
        <span class="me-1">+</span> Tambah Produk
    </a>
</div>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Terjadi kesalahan.</strong>
        Periksa kembali data yang kamu masukkan.
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm mb-4">
    <div class="card-body p-3">
        <form method="GET" action="<?php echo e(route('produk.index')); ?>">
            <div class="row g-2">
                <div class="col-lg-6">
                    <div class="input-group">
                        <span class="input-group-text bg-white">⌕</span>
                        <input
                            type="search"
                            name="cari"
                            class="form-control"
                            placeholder="Cari nama produk atau nama UMKM..."
                            value="<?php echo e(request('cari')); ?>"
                        >
                    </div>
                </div>

                <div class="col-lg-3">
                    <select name="kategori" class="form-select">
                        <option value="">Semua kategori</option>
                        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option
                                value="<?php echo e($k->id); ?>"
                                <?php echo e(request('kategori') == $k->id ? 'selected' : ''); ?>

                            >
                                <?php echo e($k->nama_kategori); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-lg-3 d-flex gap-2">
                    <button type="submit" class="btn btn-hijau flex-fill">
                        Cari Produk
                    </button>

                    <?php if(request('cari') || request('kategori')): ?>
                        <a href="<?php echo e(route('produk.index')); ?>"
                           class="btn btn-outline-secondary">
                            Reset
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card border-0 shadow-sm overflow-hidden">
    <div class="card-header bg-white border-0 px-3 pt-3 pb-2">
        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div>
                <h2 class="h6 fw-bold mb-1">Data Produk UMKM</h2>
                <p class="text-muted small mb-0">
                    Total <?php echo e($produks->total()); ?> produk terdaftar
                </p>
            </div>
            <span class="badge rounded-pill text-bg-light border">
                Katalog Produk
            </span>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0 tabel-produk">
            <thead>
                <tr>
                    <th class="ps-3">No.</th>
                    <th>Produk</th>
                    <th>Nama UMKM</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th>Status</th>
                    <th class="text-center pe-3">Aksi</th>
                </tr>
            </thead>

            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="ps-3 text-muted">
                            <?php echo e($produks->firstItem() + $loop->index); ?>

                        </td>

                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <?php if($produk->fotos->isNotEmpty()): ?>
                                    <img
                                        src="<?php echo e(asset('storage/' . $produk->fotos->first()->path)); ?>"
                                        alt="<?php echo e($produk->nama_produk); ?>"
                                        class="foto-produk"
                                    >
                                <?php else: ?>
                                    <div class="foto-placeholder">
                                        <span>▧</span>
                                    </div>
                                <?php endif; ?>

                                <div>
                                    <div class="fw-semibold nama-produk">
                                        <?php echo e($produk->nama_produk); ?>

                                    </div>
                                    <div class="text-muted small">
                                        ID: <?php echo e($produk->id); ?>

                                    </div>
                                </div>
                            </div>
                        </td>

                        <td><?php echo e($produk->nama_umkm); ?></td>

                        <td>
                            <span class="badge kategori-badge">
                                <?php echo e($produk->kategori->nama_kategori ?? '-'); ?>

                            </span>
                        </td>

                        <td class="fw-semibold text-nowrap">
                            Rp <?php echo e(number_format($produk->harga, 0, ',', '.')); ?>

                        </td>

                        <td><?php echo e($produk->stok); ?></td>

                        <td>
                            <?php if($produk->status === 'tersedia'): ?>
                                <span class="badge status-tersedia">
                                    ● Tersedia
                                </span>
                            <?php else: ?>
                                <span class="badge status-habis">
                                    ● Habis
                                </span>
                            <?php endif; ?>
                        </td>

                        <td class="pe-3">
                            <div class="d-flex justify-content-center gap-1">
                                <a
                                    href="<?php echo e(route('produk.show', $produk)); ?>"
                                    class="btn btn-sm btn-outline-success"
                                    title="Lihat detail"
                                >
                                    Lihat
                                </a>

                                <a
                                    href="<?php echo e(route('produk.edit', $produk)); ?>"
                                    class="btn btn-sm btn-outline-primary"
                                    title="Edit produk"
                                >
                                    Edit
                                </a>

                                <form
                                    action="<?php echo e(route('produk.destroy', $produk)); ?>"
                                    method="POST"
                                    onsubmit="return confirm('Yakin ingin menghapus produk ini?')"
                                >
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button
                                        type="submit"
                                        class="btn btn-sm btn-outline-danger"
                                        title="Hapus produk"
                                    >
                                        Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center py-5">
                            <div class="fs-2 mb-2">▧</div>
                            <div class="fw-semibold">Produk belum ditemukan</div>
                            <p class="text-muted small mb-3">
                                Coba ubah kata pencarian atau tambahkan produk baru.
                            </p>
                            <a href="<?php echo e(route('produk.create')); ?>"
                               class="btn btn-hijau btn-sm">
                                + Tambah Produk
                            </a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($produks->hasPages()): ?>
        <div class="card-footer bg-white border-0 px-3 py-3">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                <small class="text-muted">
                    Menampilkan <?php echo e($produks->firstItem() ?? 0); ?>–<?php echo e($produks->lastItem() ?? 0); ?>

                    dari <?php echo e($produks->total()); ?> produk
                </small>

                <?php echo e($produks->links()); ?>

            </div>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\katalog-umkm\resources\views/produk/index.blade.php ENDPATH**/ ?>