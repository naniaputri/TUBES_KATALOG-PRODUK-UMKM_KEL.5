

<?php $__env->startSection('title', 'Edit Produk'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="h3 fw-bold mb-1">Edit Produk</h1>
<p class="text-muted">Ubah data produk, lalu perbarui katalog.</p>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">Ada <?php echo e($errors->count()); ?> isian yang perlu diperbaiki.</div>
<?php endif; ?>

<div class="card card-body">
    <form action="<?php echo e(route('produk.update', $produk)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <?php echo $__env->make('produk._form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="mt-4 d-flex gap-2">
            <button type="submit" class="btn btn-hijau">Perbarui Produk</button>
            <a href="<?php echo e(route('produk.index')); ?>" class="btn btn-outline-secondary">Batal</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\katalog-umkm\resources\views/produk/edit.blade.php ENDPATH**/ ?>