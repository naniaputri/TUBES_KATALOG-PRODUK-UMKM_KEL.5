

<?php $__env->startSection('title', $produk->nama_produk); ?>

<?php $__env->startSection('content'); ?>
<nav class="mb-3 small">
    <a href="<?php echo e(route('produk.index')); ?>" class="text-success fw-semibold text-decoration-none">Produk</a>
    <span class="text-muted"> / <?php echo e($produk->nama_produk); ?></span>
</nav>

<div class="card card-body">
    <div class="row g-4">
        <div class="col-lg-6">
            <?php if($produk->fotos->count()): ?>
                <div id="galeri" class="carousel slide">
                    <div class="carousel-inner rounded">
                        <?php $__currentLoopData = $produk->fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
                                <img src="<?php echo e(asset('storage/' . $foto->path)); ?>" class="d-block w-100"
                                     alt="Foto <?php echo e($loop->iteration); ?> <?php echo e($produk->nama_produk); ?>"
                                     style="height: 380px; object-fit: cover;">
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php if($produk->fotos->count() > 1): ?>
                        <button class="carousel-control-prev" type="button" data-bs-target="#galeri" data-bs-slide="prev" aria-label="Sebelumnya">
                            <span class="carousel-control-prev-icon"></span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#galeri" data-bs-slide="next" aria-label="Berikutnya">
                            <span class="carousel-control-next-icon"></span>
                        </button>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="rounded bg-light border d-flex align-items-center justify-content-center text-muted"
                     style="height: 380px;">Belum ada foto</div>
            <?php endif; ?>
        </div>

        <div class="col-lg-6">
            <div class="mb-2">
                <span class="badge text-bg-light border"><?php echo e($produk->kategori->nama_kategori); ?></span>
                <?php if($produk->status === 'tersedia'): ?>
                    <span class="badge bg-success">Tersedia</span>
                <?php else: ?>
                    <span class="badge bg-danger">Habis</span>
                <?php endif; ?>
            </div>

            <h1 class="h3 fw-bold mb-1"><?php echo e($produk->nama_produk); ?></h1>
            <p class="text-muted">oleh <?php echo e($produk->nama_umkm); ?></p>
            <p class="fs-2 fw-bold text-success mb-3">Rp <?php echo e(number_format($produk->harga, 0, ',', '.')); ?></p>

            <h2 class="h6 fw-bold">Deskripsi</h2>
            <p><?php echo nl2br(e($produk->deskripsi ?: 'Belum ada deskripsi.')); ?></p>

            <hr>
            <dl class="row mb-4">
                <dt class="col-sm-4">Stok</dt>
                <dd class="col-sm-8"><?php echo e($produk->stok); ?> unit</dd>
                <dt class="col-sm-4">Ditambahkan</dt>
                <dd class="col-sm-8"><?php echo e($produk->created_at->format('d M Y')); ?></dd>
                <dt class="col-sm-4">Diperbarui</dt>
                <dd class="col-sm-8"><?php echo e($produk->updated_at->format('d M Y')); ?></dd>
            </dl>

            <div class="d-flex gap-2">
                <a href="<?php echo e(route('produk.edit', $produk)); ?>" class="btn btn-hijau">Edit Produk</a>
                <a href="<?php echo e(route('produk.index')); ?>" class="btn btn-outline-secondary">Kembali ke daftar</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\katalog-umkm\resources\views/produk/show.blade.php ENDPATH**/ ?>